# Activities

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **int** | Position in pagination. | [optional] 
**limit** | **int** | Number of items to retrieve (100 max). | [optional] 
**count** | **int** | Total number of items available. | [optional] 
**history** | [**\Swagger\Client\Model\Activity[]**](Activity.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


