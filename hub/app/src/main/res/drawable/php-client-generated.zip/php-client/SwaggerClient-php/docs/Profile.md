# Profile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_name** | **string** | First name of the Uber user. | [optional] 
**last_name** | **string** | Last name of the Uber user. | [optional] 
**email** | **string** | Email address of the Uber user | [optional] 
**picture** | **string** | Image URL of the Uber user. | [optional] 
**promo_code** | **string** | Promo code of the Uber user. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


